﻿namespace Customer.Domain
{
public interface ICustomerRepository : IGenericRepository<Domain.Customer>
{
}
}
